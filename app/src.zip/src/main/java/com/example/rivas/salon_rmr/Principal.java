package com.example.rivas.salon_rmr;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewSwitcher;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class Principal extends AppCompatActivity {
    //Creamos un arrayList tipo Promociones
    private List<Promociones> MyPromocion = new ArrayList<Promociones>();
    private ImageSwitcher imageSwitcher;
    private int[] galeria = {R.drawable.p, R.drawable.p1, R.drawable.p2, R.drawable.p4};
    private int posicion;
    private static final int DURACION = 9000;
    private Timer timer = null;
    private List<Principal> myPrincipal = new ArrayList<Principal>();
    private TextView TxtTema;
    private TextView TxtSubTema;
    private ImageView ImagenPromociones;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);

        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setOnNavigationItemSelectedListener(navListener);

        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();
        


        imageSwitcher = (ImageSwitcher) findViewById(R.id.imageSwitcher);
        imageSwitcher.setFactory(new ViewSwitcher.ViewFactory() {
            public View makeView() {
                ImageView imageView = new ImageView(Principal.this);
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);

                return imageView;
            }
        });

        Animation fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        Animation fadeOut = AnimationUtils.loadAnimation(this, R.anim.fade_out);
        imageSwitcher.setInAnimation(fadeIn);
        imageSwitcher.setOutAnimation(fadeOut);

        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            public void run() {
                runOnUiThread(new Runnable() {
                    public void run() {
                        imageSwitcher.setImageResource(galeria[posicion]);
                        posicion++;
                        if (posicion == galeria.length)
                            posicion = 0;
                    }
                });
            }
        }, 0, DURACION);

        //Creamos los metodos para poder Crear las diferentes promociones
        PromocionesMes();
        PromocionesView();
    }

    private void PromocionesMes() {
        MyPromocion.add(new Promociones("Pistoleado", "La definición de pistolear en el diccionario castellano es sablear.", R.drawable.portada));
        MyPromocion.add(new Promociones("Pistoleado", "La definición de pistolear en el diccionario castellano es sablear.", R.drawable.portada1));
        MyPromocion.add(new Promociones("Pistoleado", "La definición de pistolear en el diccionario castellano es sablear.", R.drawable.portada2));
        MyPromocion.add(new Promociones("Pistoleado", "La definición de pistolear en el diccionario castellano es sablear.", R.drawable.portada3));
        MyPromocion.add(new Promociones("Pistoleado", "La definición de pistolear en el diccionario castellano es sablear.", R.drawable.portada));
    }

    //Creacion de Nuestro adapter con el metodo llamado PROMOCIONESVIEW
    private void PromocionesView() {
        ArrayAdapter<Promociones> adapter = new MyListAdapter();
        ListView list = (ListView) findViewById(R.id.listview);
        list.setAdapter(adapter);
    }

    // Hacemos el metodo MyListAdapter
    private class MyListAdapter extends ArrayAdapter<Promociones> {
        public MyListAdapter() {
            super(Principal.this, R.layout.item_promociones, MyPromocion);
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            View itemView = convertView;
            if (itemView == null)
                itemView = getLayoutInflater().inflate(R.layout.item_promociones, parent, false);

            //CurrentPromociones es la posicion en la que vamos a estar
            Promociones CurrentPromociones = MyPromocion.get(position);
            ImageView imageView = (ImageView) itemView.findViewById(R.id.ImagenPromociones);
            imageView.setImageResource(CurrentPromociones.getImagenesPro());

            TextView TemaTxt = (TextView) itemView.findViewById(R.id.TxtTema);
            TemaTxt.setText(CurrentPromociones.getTema());

            TextView SubTemaTxt = (TextView) itemView.findViewById(R.id.TxtSubtema);
            SubTemaTxt.setText(CurrentPromociones.getSubtema());
            return itemView;
        }
    }
    private BottomNavigationView.OnNavigationItemSelectedListener navListener = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            Fragment selectedFragment = null;
            switch (menuItem.getItemId()) {
                case R.id.nav_home:
                    selectedFragment = new HomeFragments();
                    break;
                case R.id.nav_home1:
                    selectedFragment = new ProductFragments();
                    break;
                case R.id.nav_home2:
                    selectedFragment = new HomeFragments();
                    break;
            }
            //getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_hom, selectedFragment).commit();
            return true;
        }
        };
    }

